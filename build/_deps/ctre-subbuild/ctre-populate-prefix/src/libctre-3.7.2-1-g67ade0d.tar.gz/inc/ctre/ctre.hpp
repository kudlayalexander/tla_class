#ifndef CTRE_V2__CTRE__HPP
#define CTRE_V2__CTRE__HPP

#include "ctre/literals.hpp"
#include "ctre/functions.hpp"
#include "ctre/iterators.hpp"
#include "ctre/range.hpp"
#include "ctre/operators.hpp"

#endif
