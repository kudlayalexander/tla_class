#ifndef CTRE_V2__UNICODE_CODE_DB__HPP
#define CTRE_V2__UNICODE_CODE_DB__HPP

#define CTRE_UNICODE_SYNOPSYS_WAS_INCLUDED
#include "unicode-db/unicode-db.hpp"

#endif
